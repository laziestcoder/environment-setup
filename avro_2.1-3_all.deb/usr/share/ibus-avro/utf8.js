function utf8Decode(str) {
    return decodeURIComponent( unescape( str ) );
}
